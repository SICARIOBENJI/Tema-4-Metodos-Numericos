package metodosnumericosu4;

/**
 *
 * @author Henry chuc tec
 */
public class MetodosNumericosU4 {

    public static void main(String[] args) {
        frmPrincipal principal = new frmPrincipal();
        principal.setVisible(true);
    }
    
}
